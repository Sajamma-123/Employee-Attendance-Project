# Employee Attendance & Analytics API

A robust FastAPI and MongoDB backend service for employee attendance tracking, manual corrections with audit logging, and real-time organizational analytics.

## Tech Stack
- **Framework:** FastAPI (Python 3.11+)
- **Database:** MongoDB 7.0+ (PyMongo)
- **Validation:** Pydantic v2
- **Server:** Uvicorn

## Features
- **Attendance Tracking:**
  - `POST /attendance/punch-in`: Race-safe punch-in with IST calendar date calculation and R2 late calculation.
  - `POST /attendance/punch-out`: Closes recent punch-in, calculates R4 work hours, R3 overtime, and R5 half-day across midnight.
  - `GET /attendance`: High-performance cursor pagination and multi-attribute filtering (date range, status, employee) backed by compound indexes.
- **Audit Logging & Manual Regularization:**
  - `PATCH /attendance/{emp_code}/{date}`: Atomic record correction with optimistic concurrency control and field-level diff history tracking.
- **Advanced Analytics (MongoDB Aggregation Pipelines):**
  - `GET /analytics/employees/{emp_code}/monthly`: Employee monthly summary with working days (R7) and half-day weighted presence.
  - `GET /analytics/departments/summary`: Department-level summary preserving true headcount for employees with zero logs.
  - `GET /analytics/leaderboard/late`: Standard competition ranking (`$rank` 1, 2, 2, 4) with ties handled deterministically.
  - `GET /analytics/departments/{department}/trend`: Daily attendance trend with continuous gap filling (`$densify`) and 7-day moving averages (`$setWindowFields`).
- **Observability:**
  - `GET /health`: Database readiness probe verifying MongoDB connection via ping.
  - `GET /admin/explain/{endpoint}`: Returns execution statistics confirming index scans (`IXSCAN`) and zero collection scans (`COLLSCAN`).

## Local Setup & Running

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment:**
   Set `MONGO_URI` and `MONGO_DB` (defaults to `mongodb://localhost:27017` and `attendance_db`):
   ```bash
   # Optional .env file
   MONGO_URI=mongodb://localhost:27017
   MONGO_DB=attendance_db
   ```

3. **Seed Sample Data:**
   ```bash
   python sample_seed.py
   ```

4. **Start the API Server:**
   ```bash
   uvicorn app.main:app --port 8000
   ```

Interactive Swagger API docs will be available at: `http://localhost:8000/docs`

## Documentation & Decisions
- [REVIEW.md](file:///REVIEW.md): Analysis and fixes of defects identified in the starter app.
- [DECISIONS.md](file:///DECISIONS.md): Architectural decisions covering indexes, race safety, ranking ties, and headcount handling.
