"""Employee Attendance & Analytics API

Run:  uvicorn app.main:app --port 8000
Env:  MONGO_URI, MONGO_DB (read from environment or local .env)
"""
from __future__ import annotations

import calendar
import os
from contextlib import asynccontextmanager
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Path, Query, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field, field_validator
import pymongo
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError

load_dotenv()

# --------------------------------------------------------------------------- #
# Database Connection & Configuration
# --------------------------------------------------------------------------- #
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "attendance_db")

client: MongoClient = MongoClient(MONGO_URI, tz_aware=True)
db = client[MONGO_DB]

IST = timezone(timedelta(hours=5, minutes=30))


def init_indexes():
    """Create database indexes at startup idempotently."""
    # employees collection
    db.employees.create_index([("emp_code", 1)], unique=True)
    db.employees.create_index([("department", 1), ("joined_on", 1)])
    db.employees.create_index([("joined_on", 1)])

    # attendance_logs collection
    db.attendance_logs.create_index([("emp_code", 1), ("date", 1)], unique=True)
    db.attendance_logs.create_index([("date", -1), ("emp_code", 1)])
    db.attendance_logs.create_index([("emp_code", 1), ("date", -1)])
    db.attendance_logs.create_index([("emp_code", 1), ("punch_in", -1)])
    db.attendance_logs.create_index([("status", 1), ("date", -1), ("emp_code", 1)])
    db.attendance_logs.create_index([("date", 1), ("late_minutes", 1), ("emp_code", 1)])


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_indexes()
    yield
    client.close()


app = FastAPI(
    title="Employee Attendance & Analytics API",
    version="2.0.0",
    lifespan=lifespan,
)


# --------------------------------------------------------------------------- #
# Time & Business Rule Helpers (R1 - R10)
# --------------------------------------------------------------------------- #
def round_half_up(val: Optional[float | Decimal], decimals: int = 2) -> Optional[float]:
    """Round numbers using standard half-up rounding (R8)."""
    if val is None:
        return None
    d = Decimal(str(val))
    fmt = "0." + "0" * decimals if decimals > 0 else "0"
    return float(d.quantize(Decimal(fmt), rounding=ROUND_HALF_UP))


def truncate_epoch_ms(ms: int) -> int:
    """Drop milliseconds to whole seconds before any calculation (R1)."""
    return (ms // 1000) * 1000


def epoch_ms_to_datetime(ms: Optional[int]) -> Optional[datetime]:
    """Convert epoch milliseconds into a timezone-aware UTC datetime."""
    if ms is None:
        return None
    sec = ms // 1000
    return datetime.fromtimestamp(sec, tz=timezone.utc)


def datetime_to_epoch_ms(dt: Optional[datetime]) -> Optional[int]:
    """Convert datetime into epoch milliseconds."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def parse_hh_mm(hh_mm: str) -> tuple[int, int]:
    h, m = map(int, hh_mm.split(":"))
    return h, m


def is_overnight_shift(shift_start: str, shift_end: str) -> bool:
    """Overnight shifts cross midnight (shift_end <= shift_start)."""
    h_s, m_s = parse_hh_mm(shift_start)
    h_e, m_e = parse_hh_mm(shift_end)
    return (h_e, m_e) <= (h_s, m_s)


def get_attendance_date(punch_in_dt: datetime, shift_start: str, shift_end: str) -> str:
    """Determine the attendance calendar date in IST (R1).
    For overnight shifts, a punch earlier than shift_end belongs to the previous day's shift.
    """
    dt_ist = punch_in_dt.astimezone(IST)
    if is_overnight_shift(shift_start, shift_end):
        h_e, m_e = parse_hh_mm(shift_end)
        if dt_ist.time() < time(h_e, m_e):
            return (dt_ist.date() - timedelta(days=1)).isoformat()
    return dt_ist.date().isoformat()


def get_shift_instants(att_date_str: str, shift_start: str, shift_end: str) -> tuple[datetime, datetime]:
    """Get shift start and end instants in IST for a given attendance date."""
    d = date.fromisoformat(att_date_str)
    h_s, m_s = parse_hh_mm(shift_start)
    h_e, m_e = parse_hh_mm(shift_end)

    start_dt = datetime(d.year, d.month, d.day, h_s, m_s, 0, tzinfo=IST)
    if is_overnight_shift(shift_start, shift_end):
        end_date = d + timedelta(days=1)
        end_dt = datetime(end_date.year, end_date.month, end_date.day, h_e, m_e, 0, tzinfo=IST)
    else:
        end_dt = datetime(d.year, d.month, d.day, h_e, m_e, 0, tzinfo=IST)
    return start_dt, end_dt


def compute_late_minutes(punch_in_dt: datetime, shift_start: str, shift_end: str, att_date_str: str) -> int:
    """Calculate late minutes with a 10-minute grace period (R2).
    A punch is late only if strictly > 600 seconds after shift start.
    """
    start_dt, _ = get_shift_instants(att_date_str, shift_start, shift_end)
    diff_sec = (punch_in_dt - start_dt).total_seconds()
    if diff_sec > 600:
        return int(diff_sec // 60)
    return 0


def compute_work_hours(punch_in_dt: datetime, punch_out_dt: datetime) -> float:
    """Calculate work hours rounded half-up to 2 decimals (R4)."""
    sec = Decimal(str((punch_out_dt - punch_in_dt).total_seconds()))
    hours = sec / Decimal("3600")
    rounded = hours.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return float(rounded)


def compute_overtime_minutes(punch_out_dt: datetime, shift_start: str, shift_end: str, att_date_str: str) -> int:
    """Calculate overtime minutes past shift end (R3).
    Only counts if overtime is at least 30 minutes; otherwise 0.
    """
    _, end_dt = get_shift_instants(att_date_str, shift_start, shift_end)
    diff_sec = (punch_out_dt - end_dt).total_seconds()
    if diff_sec >= 1800:
        return int(diff_sec // 60)
    return 0


def compute_half_day(work_hours: Optional[float]) -> bool:
    """Half day flag if work hours are under 4.50 (R5)."""
    if work_hours is None:
        return False
    return work_hours < 4.50


def count_working_days(joined_on_str: str, month_str: str) -> int:
    """Count Monday to Friday workdays from joined_on to end of month (R7)."""
    year, month = map(int, month_str.split("-"))
    num_days = calendar.monthrange(year, month)[1]
    first_day = date(year, month, 1)
    last_day = date(year, month, num_days)

    joined_date = date.fromisoformat(joined_on_str)
    start_date = max(first_day, joined_date)
    if start_date > last_day:
        return 0

    count = 0
    cur = start_date
    while cur <= last_day:
        if cur.weekday() < 5:  # Mon to Fri
            count += 1
        cur += timedelta(days=1)
    return count


# --------------------------------------------------------------------------- #
# Response Serialization Helpers
# --------------------------------------------------------------------------- #
def serialize_history_entry(entry: dict) -> dict:
    at_val = entry.get("at")
    if isinstance(at_val, datetime):
        at_val = datetime_to_epoch_ms(at_val)

    changes = {}
    raw_changes = entry.get("changes") or {}
    for k, v in raw_changes.items():
        if isinstance(v, dict):
            from_v = v.get("from")
            to_v = v.get("to")
            if k in ("punch_in", "punch_out"):
                if isinstance(from_v, datetime):
                    from_v = datetime_to_epoch_ms(from_v)
                if isinstance(to_v, datetime):
                    to_v = datetime_to_epoch_ms(to_v)
            changes[k] = {"from": from_v, "to": to_v}
        else:
            changes[k] = v

    return {
        "at": at_val,
        "by": entry.get("by"),
        "reason": entry.get("reason"),
        "changes": changes,
    }


def serialize_attendance_record(doc: dict) -> dict:
    hist = [serialize_history_entry(e) for e in doc.get("history") or []]
    return {
        "emp_code": doc["emp_code"],
        "date": doc["date"],
        "status": doc["status"],
        "punch_in": datetime_to_epoch_ms(doc.get("punch_in")),
        "punch_out": datetime_to_epoch_ms(doc.get("punch_out")),
        "work_hours": doc.get("work_hours"),
        "late_minutes": doc.get("late_minutes", 0),
        "overtime_minutes": doc.get("overtime_minutes", 0),
        "half_day": doc.get("half_day", False),
        "history": hist,
    }


def serialize_employee(doc: dict) -> dict:
    return {
        "emp_code": doc["emp_code"],
        "name": doc["name"],
        "email": doc["email"],
        "department": doc["department"],
        "shift_start": doc["shift_start"],
        "shift_end": doc["shift_end"],
        "joined_on": doc["joined_on"],
        "created_at": datetime_to_epoch_ms(doc["created_at"]),
    }


def sanitize_explain_doc(obj: Any) -> Any:
    """Ensure explain results are JSON serializable."""
    if isinstance(obj, dict):
        return {k: sanitize_explain_doc(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_explain_doc(v) for v in obj]
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


# --------------------------------------------------------------------------- #
# Request Schemas
# --------------------------------------------------------------------------- #
class StatusEnum(str, Enum):
    PRESENT = "PRESENT"
    ABSENT = "ABSENT"
    LEAVE = "LEAVE"
    WFH = "WFH"
    ON_DUTY = "ON_DUTY"


class PresenceStatusEnum(str, Enum):
    PRESENT = "PRESENT"
    WFH = "WFH"
    ON_DUTY = "ON_DUTY"


class EmployeeCreate(BaseModel):
    emp_code: str = Field(..., pattern=r"^EMP\d{4,6}$", examples=["EMP0001"])
    name: str = Field(..., min_length=1, max_length=100, examples=["Asha Rao"])
    email: str = Field(..., max_length=120, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", examples=["asha@example.com"])
    department: str = Field(..., min_length=1, max_length=50, examples=["Engineering"])
    shift_start: str = Field("09:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$", examples=["09:30"])
    shift_end: str = Field("18:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$", examples=["18:30"])
    joined_on: str = Field(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$", examples=["2026-01-05"])

    @field_validator("shift_start", "shift_end", mode="before")
    @classmethod
    def normalize_shift_time(cls, v):
        """Pad single-digit hours (e.g. 9:30 -> 09:30) so user input is forgiven."""
        if isinstance(v, str) and ":" in v:
            parts = v.strip().split(":")
            if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                h, m = int(parts[0]), int(parts[1])
                if 0 <= h <= 23 and 0 <= m <= 59:
                    return f"{h:02d}:{m:02d}"
        return v

    @field_validator("joined_on", mode="before")
    @classmethod
    def normalize_joined_date(cls, v):
        """Pad single-digit months or days (e.g. 2026-7-5 -> 2026-07-05)."""
        if isinstance(v, str) and "-" in v:
            parts = v.strip().split("-")
            if len(parts) == 3 and all(p.isdigit() for p in parts):
                y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
                return f"{y:04d}-{m:02d}-{d:02d}"
        return v

    @field_validator("shift_end")
    @classmethod
    def validate_shift_times(cls, v, info):
        shift_start = info.data.get("shift_start", "09:30")
        if shift_start == v:
            raise ValueError("shift_start must differ from shift_end")
        return v


class PunchInRequest(BaseModel):
    emp_code: str = Field(..., examples=["EMP0001"])
    punched_at: Optional[int] = Field(None, strict=True, ge=100_000_000_000, le=4_102_444_800_000, examples=[1783312500000])
    status: PresenceStatusEnum = Field(PresenceStatusEnum.PRESENT, examples=["PRESENT"])


class PunchOutRequest(BaseModel):
    emp_code: str = Field(..., examples=["EMP0001"])
    punched_at: Optional[int] = Field(None, strict=True, ge=100_000_000_000, le=4_102_444_800_000, examples=[1783344900000])


class RegularizeRequest(BaseModel):
    status: Optional[StatusEnum] = Field(None, examples=["PRESENT"])
    punch_in: Optional[int] = Field(None, strict=True, ge=100_000_000_000, le=4_102_444_800_000, examples=[1783310280000])
    punch_out: Optional[int] = Field(None, strict=True, ge=100_000_000_000, le=4_102_444_800_000, examples=[1783342800000])
    reason: str = Field(..., min_length=5, max_length=200, examples=["biometric scanner glitch"])
    regularized_by: str = Field(..., min_length=1, max_length=50, examples=["hr.admin"])


# --------------------------------------------------------------------------- #
# Aggregation Pipeline Builders (Shared between endpoints and explain)
# --------------------------------------------------------------------------- #
def build_employee_monthly_pipeline(emp_code: str, month: str) -> list[dict[str, Any]]:
    year, m_num = map(int, month.split("-"))
    num_days = calendar.monthrange(year, m_num)[1]
    start_date_str = f"{month}-01"
    end_date_str = f"{month}-{num_days:02d}"

    return [
        {
            "$match": {
                "emp_code": emp_code,
                "date": {"$gte": start_date_str, "$lte": end_date_str},
            }
        },
        {
            "$addFields": {
                "day_of_week": {
                    "$dayOfWeek": {"$dateFromString": {"dateString": "$date"}}
                },
                "is_present": {
                    "$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]
                },
            }
        },
        {
            "$group": {
                "_id": None,
                "present_days": {
                    "$sum": {
                        "$cond": [
                            {
                                "$and": [
                                    {"$in": ["$day_of_week", [2, 3, 4, 5, 6]]},
                                    "$is_present",
                                ]
                            },
                            {"$cond": ["$half_day", 0.5, 1.0]},
                            0.0,
                        ]
                    }
                },
                "leave_days": {
                    "$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}
                },
                "late_count": {
                    "$sum": {"$cond": [{"$gt": ["$late_minutes", 0]}, 1, 0]}
                },
                "total_late_minutes": {"$sum": "$late_minutes"},
                "total_overtime_minutes": {"$sum": "$overtime_minutes"},
            }
        },
    ]


def build_department_summary_pipeline(month: str, department: Optional[str] = None) -> list[dict[str, Any]]:
    year, m_num = map(int, month.split("-"))
    num_days = calendar.monthrange(year, m_num)[1]
    start_date_str = f"{month}-01"
    end_date_str = f"{month}-{num_days:02d}"

    match_filter: dict[str, Any] = {"joined_on": {"$lte": end_date_str}}
    if department:
        match_filter["department"] = department

    return [
        {"$match": match_filter},
        {
            "$group": {
                "_id": "$department",
                "headcount": {"$sum": 1},
                "emp_codes": {"$push": "$emp_code"},
            }
        },
        {
            "$lookup": {
                "from": "attendance_logs",
                "let": {"dept_codes": "$emp_codes"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$in": ["$emp_code", "$$dept_codes"]},
                                    {"$gte": ["$date", start_date_str]},
                                    {"$lte": ["$date", end_date_str]},
                                ]
                            }
                        }
                    },
                    {
                        "$addFields": {
                            "day_of_week": {
                                "$dayOfWeek": {"$dateFromString": {"dateString": "$date"}}
                            },
                            "is_present": {
                                "$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]
                            },
                        }
                    },
                    {
                        "$group": {
                            "_id": None,
                            "present_days": {
                                "$sum": {
                                    "$cond": [
                                        {
                                            "$and": [
                                                {"$in": ["$day_of_week", [2, 3, 4, 5, 6]]},
                                                "$is_present",
                                            ]
                                        },
                                        {"$cond": ["$half_day", 0.5, 1.0]},
                                        0.0,
                                    ]
                                }
                            },
                            "work_hours_sum": {
                                "$sum": {
                                    "$cond": [
                                        {
                                            "$and": [
                                                "$is_present",
                                                {"$ne": ["$work_hours", None]},
                                            ]
                                        },
                                        "$work_hours",
                                        0.0,
                                    ]
                                }
                            },
                            "work_hours_count": {
                                "$sum": {
                                    "$cond": [
                                        {
                                            "$and": [
                                                "$is_present",
                                                {"$ne": ["$work_hours", None]},
                                            ]
                                        },
                                        1,
                                        0,
                                    ]
                                }
                            },
                            "late_count": {
                                "$sum": {"$cond": [{"$gt": ["$late_minutes", 0]}, 1, 0]}
                            },
                            "total_late_minutes": {"$sum": "$late_minutes"},
                            "leave_count": {
                                "$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}
                            },
                            "on_duty_count": {
                                "$sum": {"$cond": [{"$eq": ["$status", "ON_DUTY"]}, 1, 0]}
                            },
                        }
                    },
                ],
                "as": "stats",
            }
        },
        {"$sort": {"_id": 1}},
    ]


def build_late_leaderboard_pipeline(month: str, limit: int, department: Optional[str] = None) -> list[dict[str, Any]]:
    year, m_num = map(int, month.split("-"))
    num_days = calendar.monthrange(year, m_num)[1]
    start_date_str = f"{month}-01"
    end_date_str = f"{month}-{num_days:02d}"

    pipeline: list[dict[str, Any]] = [
        {
            "$match": {
                "date": {"$gte": start_date_str, "$lte": end_date_str},
                "late_minutes": {"$gt": 0},
            }
        },
        {
            "$group": {
                "_id": "$emp_code",
                "total_late_minutes": {"$sum": "$late_minutes"},
                "late_count": {"$sum": 1},
            }
        },
        {
            "$lookup": {
                "from": "employees",
                "localField": "_id",
                "foreignField": "emp_code",
                "as": "emp",
            }
        },
        {"$unwind": "$emp"},
    ]

    if department:
        pipeline.append({"$match": {"emp.department": department}})

    pipeline.extend([
        {
            "$setWindowFields": {
                "sortBy": {"total_late_minutes": -1},
                "output": {"rank": {"$rank": {}}},
            }
        },
        {"$match": {"rank": {"$lte": limit}}},
        {"$sort": {"total_late_minutes": -1, "_id": 1}},
        {
            "$project": {
                "_id": 0,
                "rank": 1,
                "emp_code": "$_id",
                "name": "$emp.name",
                "department": "$emp.department",
                "total_late_minutes": 1,
                "late_count": 1,
            }
        },
    ])
    return pipeline


def build_department_trend_pipeline(department: str, from_date: str, to_date: str, dept_emp_codes: list[str]) -> list[dict[str, Any]]:
    from_dt = datetime.fromisoformat(from_date)
    to_dt = datetime.fromisoformat(to_date) + timedelta(days=1)

    return [
        {
            "$match": {
                "emp_code": {"$in": dept_emp_codes},
                "date": {"$gte": from_date, "$lte": to_date},
            }
        },
        {
            "$addFields": {
                "dt": {"$dateFromString": {"dateString": "$date"}}
            }
        },
        {
            "$group": {
                "_id": "$dt",
                "present_count": {
                    "$sum": {
                        "$cond": [
                            {"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]},
                            {"$cond": ["$half_day", 0.5, 1.0]},
                            0.0,
                        ]
                    }
                },
                "late_count": {
                    "$sum": {"$cond": [{"$gt": ["$late_minutes", 0]}, 1, 0]}
                },
            }
        },
        {
            "$project": {
                "_id": 0,
                "dt": "$_id",
                "present_count": 1,
                "late_count": 1,
            }
        },
        {
            "$densify": {
                "field": "dt",
                "range": {
                    "step": 1,
                    "unit": "day",
                    "bounds": [from_dt, to_dt],
                },
            }
        },
        {"$sort": {"dt": 1}},
        {
            "$addFields": {
                "date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$dt"}},
                "present_count": {"$ifNull": ["$present_count", 0.0]},
                "late_count": {"$ifNull": ["$late_count", 0]},
                "day_of_week": {"$dayOfWeek": "$dt"},
            }
        },
        {
            "$addFields": {
                "is_working_day": {"$in": ["$day_of_week", [2, 3, 4, 5, 6]]}
            }
        },
        {
            "$lookup": {
                "from": "employees",
                "let": {"current_date": "$date"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$eq": ["$department", department]},
                                    {"$lte": ["$joined_on", "$$current_date"]},
                                ]
                            }
                        }
                    },
                    {"$count": "count"},
                ],
                "as": "hc",
            }
        },
        {
            "$addFields": {
                "headcount": {"$ifNull": [{"$first": "$hc.count"}, 0]}
            }
        },
        {
            "$addFields": {
                "attendance_rate": {
                    "$cond": [
                        {
                            "$and": [
                                "$is_working_day",
                                {"$gt": ["$headcount", 0]},
                            ]
                        },
                        {
                            "$round": [
                                {"$divide": ["$present_count", "$headcount"]},
                                4,
                            ]
                        },
                        None,
                    ]
                }
            }
        },
        {
            "$setWindowFields": {
                "sortBy": {"dt": 1},
                "output": {
                    "moving_avg_7d": {
                        "$avg": "$attendance_rate",
                        "window": {
                            "documents": [-6, "current"],
                        },
                    }
                },
            }
        },
        {
            "$addFields": {
                "moving_avg_7d": {
                    "$cond": [
                        {"$ne": ["$moving_avg_7d", None]},
                        {"$round": ["$moving_avg_7d", 4]},
                        None,
                    ]
                }
            }
        },
        {
            "$project": {
                "_id": 0,
                "date": 1,
                "is_working_day": 1,
                "headcount": 1,
                "present_count": 1,
                "late_count": 1,
                "attendance_rate": 1,
                "moving_avg_7d": 1,
            }
        },
    ]


# --------------------------------------------------------------------------- #
# Endpoints
# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
@app.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
def dashboard():
    """Clean editorial dashboard displaying live MongoDB attendance analytics."""
    # 1. Pre-render Department Summary
    dept_pipe = build_department_summary_pipeline("2026-07")
    raw_depts = list(db.employees.aggregate(dept_pipe))
    dept_rows_html = []
    for d in raw_depts:
        stats = d.get("stats", [])
        if stats:
            s = stats[0]
            work_sum = Decimal(str(s.get("work_hours_sum", 0)))
            work_cnt = s.get("work_hours_count", 0)
            avg_h = (
                (work_sum / Decimal(str(work_cnt))).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_UP
                )
                if work_cnt > 0
                else None
            )
            avg_h_str = f"{float(avg_h):.2f} hrs" if avg_h is not None else "&mdash;"
            dept_rows_html.append(
                f"<tr>"
                f"<td><span style=\"font-weight: 500;\">{d['_id']}</span></td>"
                f"<td>{d.get('headcount', 0)}</td>"
                f"<td>{s.get('present_days', 0.0)}</td>"
                f"<td>{avg_h_str}</td>"
                f"<td>{s.get('late_count', 0)}</td>"
                f"<td>{s.get('total_late_minutes', 0)} min</td>"
                f"<td>{s.get('leave_count', 0)}</td>"
                f"</tr>"
            )
        else:
            dept_rows_html.append(
                f"<tr>"
                f"<td><span style=\"font-weight: 500;\">{d['_id']}</span></td>"
                f"<td>{d.get('headcount', 0)}</td>"
                f"<td>0.0</td>"
                f"<td>&mdash;</td>"
                f"<td>0</td>"
                f"<td>0 min</td>"
                f"<td>0</td>"
                f"</tr>"
            )

    dept_table_body = "\n".join(dept_rows_html) if dept_rows_html else "<tr><td colspan='7'>No department records found.</td></tr>"

    # 2. Pre-render Late Leaderboard
    lead_pipe = build_late_leaderboard_pipeline("2026-07", limit=10)
    lead_rows = list(db.attendance_logs.aggregate(lead_pipe))
    lead_rows_html = []
    for item in lead_rows:
        lead_rows_html.append(
            f"<tr>"
            f"<td><span class=\"code-tag\">#{item['rank']}</span></td>"
            f"<td><span class=\"code-tag\">{item['emp_code']}</span></td>"
            f"<td><span style=\"font-weight: 500;\">{item['name']}</span></td>"
            f"<td>{item['department']}</td>"
            f"<td style=\"color: var(--accent-warm); font-weight: 500;\">{item['total_late_minutes']} min</td>"
            f"<td>{item['late_count']}</td>"
            f"</tr>"
        )
    lead_table_body = "\n".join(lead_rows_html) if lead_rows_html else "<tr><td colspan='6'>No late attendance logs found.</td></tr>"

    # 3. Pre-render Python Fullstack Trend Series
    p_emps = [e["emp_code"] for e in db.employees.find({"department": "Python Fullstack"}, {"emp_code": 1})]
    trend_rows_html = []
    if p_emps:
        t_pipe = build_department_trend_pipeline("Python Fullstack", "2026-07-06", "2026-07-10", p_emps)
        t_rows = list(db.attendance_logs.aggregate(t_pipe))
        for row in t_rows:
            att_rate_str = f"{row['attendance_rate']*100:.1f}%" if row.get("attendance_rate") is not None else "&mdash;"
            m_avg_str = f"{row['moving_avg_7d']*100:.1f}%" if row.get("moving_avg_7d") is not None else "&mdash;"
            trend_rows_html.append(
                f"<tr>"
                f"<td><span class=\"code-tag\">{row['date']}</span></td>"
                f"<td>{row['headcount']}</td>"
                f"<td>{row['present_count']}</td>"
                f"<td>{row['late_count']}</td>"
                f"<td>{att_rate_str}</td>"
                f"<td style=\"color: var(--accent-warm); font-weight: 500;\">{m_avg_str}</td>"
                f"</tr>"
            )
    trend_table_body = "\n".join(trend_rows_html) if trend_rows_html else "<tr><td colspan='6'>No trend records available.</td></tr>"

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Workforce Attendance Analytics</title>
  <style>
    :root {{
      --bg: #111113;
      --surface: #18181b;
      --surface-hover: #202024;
      --border: #27272a;
      --border-subtle: #202023;
      --text-main: #f4f4f5;
      --text-muted: #a1a1aa;
      --text-subtle: #71717a;
      --accent-warm: #d97706;
      --accent-hover: #b45309;
      --font-serif: Newsreader, Charter, "Iowan Old Style", Georgia, "Times New Roman", serif;
      --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background-color: var(--bg);
      color: var(--text-main);
      font-family: var(--font-sans);
      font-size: 14px;
      line-height: 1.6;
      padding: 36px 28px;
      -webkit-font-smoothing: antialiased;
    }}
    .container {{
      max-width: 1100px;
      margin: 0 auto;
    }}
    header {{
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      border-bottom: 1px solid var(--border);
      padding-bottom: 24px;
      margin-bottom: 32px;
      flex-wrap: wrap;
      gap: 16px;
    }}
    .header-title {{
      font-family: var(--font-serif);
      font-size: 32px;
      font-weight: 400;
      color: var(--text-main);
      letter-spacing: -0.01em;
    }}
    .header-subtitle {{
      color: var(--text-muted);
      font-size: 14px;
      margin-top: 4px;
    }}
    .nav-actions {{
      display: flex;
      align-items: center;
      gap: 12px;
    }}
    .btn {{
      display: inline-block;
      background: #27272a;
      color: var(--text-main);
      border: 1px solid #3f3f46;
      padding: 7px 16px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      text-decoration: none;
      transition: background 0.15s ease, border-color 0.15s ease;
    }}
    .btn:hover {{
      background: #3f3f46;
      color: #fff;
    }}
    .section-eyebrow {{
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--accent-warm);
      margin-bottom: 6px;
    }}
    .section-heading {{
      font-family: var(--font-serif);
      font-size: 22px;
      font-weight: 400;
      color: var(--text-main);
      margin-bottom: 16px;
    }}
    .cards-row {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }}
    .info-card {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 20px;
    }}
    .info-label {{
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--text-subtle);
      margin-bottom: 6px;
    }}
    .info-value {{
      font-family: var(--font-serif);
      font-size: 26px;
      font-weight: 400;
      color: var(--text-main);
    }}
    .info-desc {{
      font-size: 12px;
      color: var(--text-muted);
      margin-top: 4px;
    }}
    .block {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 24px;
      margin-bottom: 28px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      margin-top: 8px;
      font-size: 13px;
    }}
    th {{
      text-align: left;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--text-subtle);
      padding: 12px 14px;
      border-bottom: 1px solid var(--border);
    }}
    td {{
      padding: 14px;
      border-bottom: 1px solid var(--border-subtle);
      color: var(--text-main);
    }}
    tr:last-child td {{
      border-bottom: none;
    }}
    tr:hover td {{
      background: rgba(255, 255, 255, 0.015);
    }}
    .code-tag {{
      font-family: var(--font-mono);
      font-size: 12px;
      background: #202024;
      border: 1px solid var(--border);
      padding: 2px 6px;
      border-radius: 4px;
      color: #e4e4e7;
    }}
    .link-group {{
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-top: 8px;
    }}
    .text-link {{
      color: #d4d4d8;
      text-decoration: underline;
      text-decoration-color: #52525b;
      text-underline-offset: 3px;
      font-size: 13px;
      transition: color 0.15s ease;
    }}
    .text-link:hover {{
      color: #fff;
      text-decoration-color: #a1a1aa;
    }}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div>
        <h1 class="header-title">Employee Attendance &amp; Analytics</h1>
      </div>
      <div class="nav-actions">
        <a href="/docs" class="btn">API Documentation</a>
      </div>
    </header>

    <div class="cards-row">
      <div class="info-card">
        <div class="info-label">Active Period</div>
        <div class="info-value">July 2026</div>
        <div class="info-desc">Standard monthly evaluation window</div>
      </div>
      <div class="info-card">
        <div class="info-label">System Status</div>
        <div class="info-value">Active &amp; Ready</div>
        <div class="info-desc">MongoDB 7.0 database operational</div>
      </div>
      <div class="info-card">
        <div class="info-label">Direct API Endpoints</div>
        <div class="link-group">
          <a class="text-link" href="/analytics/departments/summary?month=2026-07" target="_blank">Department Summary (JSON) &rarr;</a>
          <a class="text-link" href="/analytics/leaderboard/late?month=2026-07" target="_blank">Late Leaderboard (JSON) &rarr;</a>
          <a class="text-link" href="/analytics/departments/Python%20Fullstack/trend?from=2026-07-06&to=2026-07-10" target="_blank">Python Fullstack Trend (JSON) &rarr;</a>
        </div>
      </div>
    </div>

    <div class="block">
      <div class="section-eyebrow">Department Overview</div>
      <h2 class="section-heading">Department Attendance Summary</h2>
      <table>
        <thead>
          <tr>
            <th>Department</th>
            <th>Headcount</th>
            <th>Present Days</th>
            <th>Average Work Hours</th>
            <th>Late Punches</th>
            <th>Late Minutes</th>
            <th>Leave Days</th>
          </tr>
        </thead>
        <tbody>
          {dept_table_body}
        </tbody>
      </table>
    </div>

    <div class="block">
      <div class="section-eyebrow">Punctuality Leaderboard</div>
      <h2 class="section-heading">Late Arrival Overview</h2>
      <table>
        <thead>
          <tr>
            <th style="width: 80px;">Rank</th>
            <th>Emp Code</th>
            <th>Name</th>
            <th>Department</th>
            <th>Late Duration</th>
            <th>Late Punches</th>
          </tr>
        </thead>
        <tbody>
          {lead_table_body}
        </tbody>
      </table>
    </div>

    <div class="block">
      <div class="section-eyebrow">Daily Series</div>
      <h2 class="section-heading">Python Fullstack Attendance &amp; Moving Average Trend</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Headcount</th>
            <th>Present Count</th>
            <th>Late Count</th>
            <th>Attendance Rate</th>
            <th>7-Day Moving Avg</th>
          </tr>
        </thead>
        <tbody>
          {trend_table_body}
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>"""
    return html_content


@app.get("/health", tags=["system"])
def health():
    """Readiness probe. Returns 200 if MongoDB answers ping, else 503."""
    try:
        client.admin.command("ping")
        return {"status": "ok"}
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database unavailable",
        ) from exc


@app.post("/employees", status_code=status.HTTP_201_CREATED, tags=["employees"])
def create_employee(body: EmployeeCreate):
    """Create an employee. Enforced unique by database index."""
    if body.shift_start == body.shift_end:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="shift_start must differ from shift_end",
        )

    now_dt = datetime.now(timezone.utc).replace(microsecond=0)
    doc = body.model_dump()
    doc["created_at"] = now_dt

    try:
        db.employees.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="emp_code already exists",
        )

    return serialize_employee(doc)


@app.get("/employees", tags=["employees"])
def list_employees(
    department: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """List employees sorted by emp_code ascending."""
    q: dict[str, Any] = {}
    if department:
        q["department"] = department

    total = db.employees.count_documents(q)
    skip = (page - 1) * page_size
    cursor = db.employees.find(q).sort("emp_code", 1).skip(skip).limit(page_size)
    items = [serialize_employee(d) for d in cursor]

    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@app.post("/attendance/punch-in", status_code=status.HTTP_201_CREATED, tags=["attendance"])
def punch_in(body: PunchInRequest):
    """Record an employee punch-in."""
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Employee not found",
        )

    if body.punched_at is not None:
        trunc_ms = truncate_epoch_ms(body.punched_at)
        in_dt = epoch_ms_to_datetime(trunc_ms)
    else:
        in_dt = datetime.now(timezone.utc).replace(microsecond=0)

    att_date = get_attendance_date(in_dt, emp["shift_start"], emp["shift_end"])
    late_min = compute_late_minutes(in_dt, emp["shift_start"], emp["shift_end"], att_date)

    doc = {
        "emp_code": body.emp_code,
        "date": att_date,
        "status": body.status.value,
        "punch_in": in_dt,
        "punch_out": None,
        "work_hours": None,
        "late_minutes": late_min,
        "overtime_minutes": 0,
        "half_day": False,
        "history": [],
    }

    try:
        db.attendance_logs.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="already punched in for this date",
        )

    return serialize_attendance_record(doc)


@app.post("/attendance/punch-out", status_code=status.HTTP_200_OK, tags=["attendance"])
def punch_out(body: PunchOutRequest):
    """Record a punch-out closing the employee's most recent open record."""
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Employee not found",
        )

    if body.punched_at is not None:
        trunc_ms = truncate_epoch_ms(body.punched_at)
        out_dt = epoch_ms_to_datetime(trunc_ms)
    else:
        out_dt = datetime.now(timezone.utc).replace(microsecond=0)

    # Find the most recent record with punch_in <= punched_at
    record = db.attendance_logs.find_one(
        {"emp_code": body.emp_code, "punch_in": {"$lte": out_dt}},
        sort=[("punch_in", -1)],
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No punch-in record found for employee",
        )

    in_dt = record["punch_in"]
    if in_dt.tzinfo is None:
        in_dt = in_dt.replace(tzinfo=timezone.utc)

    # Validation
    if out_dt <= in_dt:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="punched_at must be strictly after punch_in",
        )
    if (out_dt - in_dt).total_seconds() > 24 * 3600:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="punched_at cannot be more than 24 hours after punch_in",
        )

    # Check if already punched out
    if record.get("punch_out") is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Attendance record is already punched out",
        )

    # Compute derived values
    wh = compute_work_hours(in_dt, out_dt)
    ot = compute_overtime_minutes(out_dt, emp["shift_start"], emp["shift_end"], record["date"])
    hd = compute_half_day(wh)

    # Atomic update to avoid race conditions
    updated_doc = db.attendance_logs.find_one_and_update(
        {"_id": record["_id"], "punch_out": None},
        {
            "$set": {
                "punch_out": out_dt,
                "work_hours": wh,
                "overtime_minutes": ot,
                "half_day": hd,
            }
        },
        return_document=pymongo.ReturnDocument.AFTER,
    )
    if not updated_doc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Attendance record was already punched out concurrently",
        )

    return serialize_attendance_record(updated_doc)


@app.get("/attendance", tags=["attendance"])
def list_attendance(
    emp_code: Optional[str] = None,
    date_from: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    date_to: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    status_filter: Optional[StatusEnum] = Query(None, alias="status"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """List attendance records sorted by date descending, then emp_code ascending."""
    if date_from and date_to and date_from > date_to:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="date_from cannot be after date_to",
        )

    q: dict[str, Any] = {}
    if emp_code:
        q["emp_code"] = emp_code
    if status_filter:
        q["status"] = status_filter.value

    date_q: dict[str, Any] = {}
    if date_from:
        date_q["$gte"] = date_from
    if date_to:
        date_q["$lte"] = date_to
    if date_q:
        q["date"] = date_q

    total = db.attendance_logs.count_documents(q)
    skip = (page - 1) * page_size
    cursor = db.attendance_logs.find(q).sort([("date", -1), ("emp_code", 1)]).skip(skip).limit(page_size)
    items = [serialize_attendance_record(d) for d in cursor]

    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@app.patch("/attendance/{emp_code}/{date}", tags=["attendance"])
def regularize_attendance(
    emp_code: str = Path(...),
    date: str = Path(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    body: RegularizeRequest = ...,
):
    """Regularize (manually correct) one day's record with audit history."""
    emp = db.employees.find_one({"emp_code": emp_code})
    if not emp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Employee not found",
        )

    record = db.attendance_logs.find_one({"emp_code": emp_code, "date": date})
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Attendance record not found",
        )

    curr_status = record["status"]
    curr_in = record.get("punch_in")
    curr_out = record.get("punch_out")
    if curr_in and curr_in.tzinfo is None:
        curr_in = curr_in.replace(tzinfo=timezone.utc)
    if curr_out and curr_out.tzinfo is None:
        curr_out = curr_out.replace(tzinfo=timezone.utc)

    curr_work_hours = record.get("work_hours")
    curr_late = record.get("late_minutes", 0)
    curr_ot = record.get("overtime_minutes", 0)
    curr_half = record.get("half_day", False)
    curr_history = record.get("history") or []

    # Setting ABSENT or LEAVE clears both punch times
    target_status = body.status.value if body.status is not None else curr_status
    if target_status in ("ABSENT", "LEAVE"):
        if body.punch_in is not None or body.punch_out is not None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="punch_in and punch_out cannot be supplied when status is ABSENT or LEAVE",
            )
        final_in = None
        final_out = None
        final_work_hours = None
        final_late = 0
        final_ot = 0
        final_half = False
    else:
        # Presence status requires punch_in
        if body.punch_in is not None:
            final_in = epoch_ms_to_datetime(truncate_epoch_ms(body.punch_in))
        else:
            final_in = curr_in

        if final_in is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Presence status requires a punch_in",
            )

        calc_date = get_attendance_date(final_in, emp["shift_start"], emp["shift_end"])
        if calc_date != date:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"punch_in belongs to attendance date {calc_date}, expected {date}",
            )

        if body.punch_out is not None:
            final_out = epoch_ms_to_datetime(truncate_epoch_ms(body.punch_out))
        else:
            final_out = curr_out

        if final_out is not None:
            if final_out <= final_in:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="punch_out must be strictly after punch_in",
                )
            if (final_out - final_in).total_seconds() > 24 * 3600:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="punch_out cannot be more than 24 hours after punch_in",
                )
            final_work_hours = compute_work_hours(final_in, final_out)
            final_ot = compute_overtime_minutes(final_out, emp["shift_start"], emp["shift_end"], date)
            final_half = compute_half_day(final_work_hours)
        else:
            final_work_hours = None
            final_ot = 0
            final_half = False

        final_late = compute_late_minutes(final_in, emp["shift_start"], emp["shift_end"], date)

    # Detect fields that actually changed
    changes: dict[str, dict[str, Any]] = {}
    if curr_status != target_status:
        changes["status"] = {"from": curr_status, "to": target_status}
    if curr_in != final_in:
        changes["punch_in"] = {"from": curr_in, "to": final_in}
    if curr_out != final_out:
        changes["punch_out"] = {"from": curr_out, "to": final_out}
    if curr_work_hours != final_work_hours:
        changes["work_hours"] = {"from": curr_work_hours, "to": final_work_hours}
    if curr_late != final_late:
        changes["late_minutes"] = {"from": curr_late, "to": final_late}
    if curr_ot != final_ot:
        changes["overtime_minutes"] = {"from": curr_ot, "to": final_ot}
    if curr_half != final_half:
        changes["half_day"] = {"from": curr_half, "to": final_half}

    if not changes:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No changes detected in regularization request",
        )

    now_dt = datetime.now(timezone.utc).replace(microsecond=0)
    history_entry = {
        "at": now_dt,
        "by": body.regularized_by,
        "reason": body.reason,
        "changes": changes,
    }

    # Optimistic locking on history length
    updated = db.attendance_logs.find_one_and_update(
        {
            "_id": record["_id"],
            "history": {"$size": len(curr_history)},
        },
        {
            "$set": {
                "status": target_status,
                "punch_in": final_in,
                "punch_out": final_out,
                "work_hours": final_work_hours,
                "late_minutes": final_late,
                "overtime_minutes": final_ot,
                "half_day": final_half,
            },
            "$push": {
                "history": history_entry,
            },
        },
        return_document=pymongo.ReturnDocument.AFTER,
    )
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Concurrent modification conflict during regularization",
        )

    return serialize_attendance_record(updated)


@app.get("/analytics/employees/{emp_code}/monthly", tags=["analytics"])
def employee_monthly(
    emp_code: str = Path(...),
    month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"),
):
    """Monthly attendance summary for one employee."""
    emp = db.employees.find_one({"emp_code": emp_code})
    if not emp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Employee not found",
        )

    working_days = count_working_days(emp["joined_on"], month)
    pipeline = build_employee_monthly_pipeline(emp_code, month)
    res = list(db.attendance_logs.aggregate(pipeline))

    if res:
        agg = res[0]
        present_days = float(agg.get("present_days", 0.0))
        leave_days = int(agg.get("leave_days", 0))
        late_count = int(agg.get("late_count", 0))
        total_late = int(agg.get("total_late_minutes", 0))
        total_ot = int(agg.get("total_overtime_minutes", 0))
    else:
        present_days = 0.0
        leave_days = 0
        late_count = 0
        total_late = 0
        total_ot = 0

    if working_days > 0:
        attendance_pct = round_half_up((present_days / working_days) * 100.0, 2)
    else:
        attendance_pct = None

    return {
        "emp_code": emp_code,
        "month": month,
        "working_days": working_days,
        "present_days": round_half_up(present_days, 2),
        "leave_days": leave_days,
        "late_count": late_count,
        "total_late_minutes": total_late,
        "total_overtime_minutes": total_ot,
        "attendance_pct": attendance_pct,
    }


@app.get("/analytics/departments/summary", tags=["analytics"])
def department_summary(
    month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"),
    department: Optional[str] = None,
):
    """Department summary for a month preserving headcount for 0-log staff."""
    pipeline = build_department_summary_pipeline(month, department)
    items = []

    for doc in db.employees.aggregate(pipeline):
        dept_name = doc["_id"]
        headcount = doc["headcount"]
        stats_list = doc.get("stats") or []
        if stats_list:
            s = stats_list[0]
            present_days = round_half_up(s.get("present_days", 0.0), 2)
            wh_sum = s.get("work_hours_sum", 0.0)
            wh_cnt = s.get("work_hours_count", 0)
            avg_wh = round_half_up(wh_sum / wh_cnt, 2) if wh_cnt > 0 else None
            late_count = int(s.get("late_count", 0))
            total_late = int(s.get("total_late_minutes", 0))
            leave_count = int(s.get("leave_count", 0))
            on_duty_count = int(s.get("on_duty_count", 0))
        else:
            present_days = 0.0
            avg_wh = None
            late_count = 0
            total_late = 0
            leave_count = 0
            on_duty_count = 0

        items.append({
            "department": dept_name,
            "headcount": headcount,
            "present_days": present_days,
            "avg_work_hours": avg_wh,
            "late_count": late_count,
            "total_late_minutes": total_late,
            "leave_count": leave_count,
            "on_duty_count": on_duty_count,
        })

    return {"month": month, "items": items}


@app.get("/analytics/leaderboard/late", tags=["analytics"])
def late_leaderboard(
    month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"),
    limit: int = Query(10, ge=1, le=50),
    department: Optional[str] = None,
):
    """Late-comers leaderboard for a month using standard competition ranking."""
    pipeline = build_late_leaderboard_pipeline(month, limit, department)
    items = list(db.attendance_logs.aggregate(pipeline))
    return {"month": month, "items": items}


@app.get("/analytics/departments/{department}/trend", tags=["analytics"])
def department_trend(
    department: str = Path(...),
    from_date: str = Query(..., alias="from", pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    to_date: str = Query(..., alias="to", pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
):
    """Daily attendance trend for a department with gap-filling ($densify) and 7-day moving average."""
    dept_exists = db.employees.find_one({"department": department})
    if not dept_exists:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Department not found",
        )

    d_from = date.fromisoformat(from_date)
    d_to = date.fromisoformat(to_date)
    if d_to < d_from:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="to date cannot be earlier than from date",
        )
    if (d_to - d_from).days > 92:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Date range exceeds 92 days",
        )

    dept_emp_codes = [e["emp_code"] for e in db.employees.find({"department": department}, {"emp_code": 1})]
    pipeline = build_department_trend_pipeline(department, from_date, to_date, dept_emp_codes)
    items = list(db.attendance_logs.aggregate(pipeline))
    return {"department": department, "items": items}


# --------------------------------------------------------------------------- #
# Explain Endpoint: /admin/explain/{endpoint}
# --------------------------------------------------------------------------- #
@app.get("/admin/explain/{endpoint}", tags=["admin"])
def explain_endpoint(
    endpoint: str = Path(..., pattern=r"^(attendance_list|employee_monthly|department_summary|late_leaderboard|department_trend)$"),
    emp_code: Optional[str] = None,
    month: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])$"),
    department: Optional[str] = None,
    limit: int = Query(10, ge=1, le=50),
    date_from: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    date_to: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    status_filter: Optional[StatusEnum] = Query(None, alias="status"),
    from_date: Optional[str] = Query(None, alias="from", pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    to_date: Optional[str] = Query(None, alias="to", pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """Runs MongoDB explain with executionStats verbosity for an endpoint's main query or aggregation."""
    if endpoint == "attendance_list":
        if date_from and date_to and date_from > date_to:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="date_from cannot be after date_to",
            )
        q: dict[str, Any] = {}
        if emp_code:
            q["emp_code"] = emp_code
        if status_filter:
            q["status"] = status_filter.value
        date_q: dict[str, Any] = {}
        if date_from:
            date_q["$gte"] = date_from
        if date_to:
            date_q["$lte"] = date_to
        if date_q:
            q["date"] = date_q

        skip = (page - 1) * page_size
        cursor = db.attendance_logs.find(q).sort([("date", -1), ("emp_code", 1)]).skip(skip).limit(page_size)
        explain_res = cursor.explain()
        return {
            "endpoint": endpoint,
            "collection": "attendance_logs",
            "explain": sanitize_explain_doc(explain_res),
        }

    elif endpoint == "employee_monthly":
        if not emp_code or not month:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="emp_code and month are required for employee_monthly",
            )
        pipeline = build_employee_monthly_pipeline(emp_code, month)
        explain_res = db.command({
            "explain": {
                "aggregate": "attendance_logs",
                "pipeline": pipeline,
                "cursor": {},
            },
            "verbosity": "executionStats",
        })
        return {
            "endpoint": endpoint,
            "collection": "attendance_logs",
            "explain": sanitize_explain_doc(explain_res),
        }

    elif endpoint == "department_summary":
        if not month:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="month is required for department_summary",
            )
        pipeline = build_department_summary_pipeline(month, department)
        explain_res = db.command({
            "explain": {
                "aggregate": "employees",
                "pipeline": pipeline,
                "cursor": {},
            },
            "verbosity": "executionStats",
        })
        return {
            "endpoint": endpoint,
            "collection": "employees",
            "explain": sanitize_explain_doc(explain_res),
        }

    elif endpoint == "late_leaderboard":
        if not month:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="month is required for late_leaderboard",
            )
        pipeline = build_late_leaderboard_pipeline(month, limit, department)
        explain_res = db.command({
            "explain": {
                "aggregate": "attendance_logs",
                "pipeline": pipeline,
                "cursor": {},
            },
            "verbosity": "executionStats",
        })
        return {
            "endpoint": endpoint,
            "collection": "attendance_logs",
            "explain": sanitize_explain_doc(explain_res),
        }

    elif endpoint == "department_trend":
        if not department or not from_date or not to_date:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="department, from, and to are required for department_trend",
            )
        d_from = date.fromisoformat(from_date)
        d_to = date.fromisoformat(to_date)
        if d_to < d_from:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="to date cannot be earlier than from date",
            )
        if (d_to - d_from).days > 92:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Date range exceeds 92 days",
            )

        dept_emp_codes = [e["emp_code"] for e in db.employees.find({"department": department}, {"emp_code": 1})]
        pipeline = build_department_trend_pipeline(department, from_date, to_date, dept_emp_codes)
        explain_res = db.command({
            "explain": {
                "aggregate": "attendance_logs",
                "pipeline": pipeline,
                "cursor": {},
            },
            "verbosity": "executionStats",
        })
        return {
            "endpoint": endpoint,
            "collection": "attendance_logs",
            "explain": sanitize_explain_doc(explain_res),
        }
