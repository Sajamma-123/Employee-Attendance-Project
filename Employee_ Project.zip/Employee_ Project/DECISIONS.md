# DECISIONS.md (about 150-200 words in total - plain language, your own words)

1. **Indexes.**
I created unique indexes on `employees.emp_code` (guaranteeing employee uniqueness and accelerating lookups) and `attendance_logs(emp_code, date)` (enforcing one log per day and race-safety). For query performance, I added `attendance_logs(date: -1, emp_code: 1)` (for fast list paging) and `attendance_logs(date: 1, late_minutes: 1, emp_code: 1)` (to scan only late records in the leaderboard without collection scans). I considered and rejected a separate index on `punch_out` alone, as punch-out lookups are already covered by `(emp_code, punch_in)`.

2. **Punch-in race.**
Both concurrent requests compute the attendance date and attempt an `insert_one`. MongoDB atomically enforces the unique `(emp_code, date)` index at the storage engine level. Exactly one request succeeds, returning HTTP 201. The losing request encounters a `DuplicateKeyError`, which is trapped and returned as HTTP 409 Conflict. No check-then-insert race condition exists.

3. **Ties.**
The pipeline applies MongoDB `$setWindowFields` with `$rank` for standard competition ranking (e.g., 1, 2, 2, 4). The filter `rank <= limit` applies after ranking. If two employees tie at the cutoff, both are included (exceeding `limit`), ordered by `emp_code` ascending per the contract.

4. **Headcount.**
The aggregation pipeline roots in `employees` (filtering `joined_on <= month_end`), grouping by department to capture total headcount before doing a `$lookup` to `attendance_logs`. Employees and departments with zero logs retain their true headcount, while derived metrics default to 0 and average work hours to null.

5. **One thing you would change** if this had to serve 100x the data.
I would implement incremental pre-aggregations using MongoDB change streams or periodic `$merge` into a read-optimized collection, allowing monthly analytics and trends to be fetched in O(1) time rather than scanning millions of logs on demand.
